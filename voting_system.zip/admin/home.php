<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<link href="candidate.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style1 {
	font-size: 36px;
	font-weight: bold;
}
.style5 {font-size: 36px}
.style6 {font-size: 24pt}
.style7 {font-size: 10pt}
-->
</style>
</head>

<body><br><br>
<table width="800" border="1" align="center">
  <tr>
    <td align="center" valign="middle" class="TrHover"><span class="style1">ADMINISTRATION PANEL </span></td>
  </tr>
  <tr>
    <td class="TrHover style5">&nbsp;</td>
  </tr>
  <tr>
    <td class="TrHover"><a href="position.php" class="TrHover style6">Position Information</a> </td>
  </tr>
  <tr>
    <td class="TrHover"><a href="candidate.php" class="style5">Candidate Information</a> </td>
  </tr>
  <tr>
    <td class="TrHover"><a href="students.php" class="style5">Student Information</a> </td>
  </tr>
  <tr>
    <td class="TrHover"><a href="tally.php" class="style5">Tally Sheet </a></td>
  </tr>
  <tr>
    <td class="TrHover">&nbsp;</td>
  </tr>
  <tr>
    <td align="center" class="TrHover"><a href="index.php" class="style7">Log-out</a> </td>
  </tr>
</table>
</body>
<div id="Footer" align="center"> 
 <p>&copy; <?php echo date('Y');?>.All rights reserved E-voting system</p>
        <p>Designed & Developed by  <b>Harjeet kaur</b></p>
		
  </div>
</html>
